﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Data;
using System.Data.OleDb;
using System.Text;
using Newtonsoft.Json.Linq;
using Newtonsoft.Json;
using System.Linq;

namespace Json_Excel_TestCases
{
    class Program
    {
        static string json = Directory.GetCurrentDirectory() + "\\Input\\ESIGNTSS-PUTDOCUMENTS.json";

        static void Main(string[] args)
        {
            try
            {
                RunTestcases();
            }
            catch (Exception ex)
            {
                string newpath = System.Reflection.Assembly.GetExecutingAssembly().CodeBase;
                File.WriteAllText(Directory.GetCurrentDirectory() + "\\log.txt", ex.StackTrace.ToString());
            }
        }

        public static Dictionary<string, string> LoadJson()
        {
            Dictionary<string, string> nodes = new Dictionary<string, string>();
            JObject rootObject = JObject.Parse(File.ReadAllText(json));
            ParseJson(rootObject, nodes);
            return nodes;
        }

        public static DataTable ReadExcel()
        {
            var ds = new DataSet();
            var connectionString = "Provider=Microsoft.ACE.OLEDB.12.0;Data Source=" + Directory.GetCurrentDirectory() + "\\Input\\ESIGNTEST.xlsx" + ";Extended Properties=\"Excel 12.0;IMEX=1;HDR=NO;TypeGuessRows=0;ImportMixedTypes=Text\""; ;
            using (var conn = new OleDbConnection(connectionString))
            {
                conn.Open();
                var sheets = conn.GetOleDbSchemaTable(OleDbSchemaGuid.Tables, new object[] { null, null, null, "TABLE" });
                using (var cmd = conn.CreateCommand())
                {
                    cmd.CommandText = "SELECT * FROM [" + sheets.Rows[0]["TABLE_NAME"].ToString() + "] ";

                    var adapter = new OleDbDataAdapter(cmd);
                    adapter.Fill(ds);
                }
            }
            return ds.Tables[0];
        }

        public static void RunTestcases()
        {
            Dictionary<string, string> dicJson = LoadJson();
            Dictionary<string, string> newdicValue = new Dictionary<string, string>();
            DataTable dt = ReadExcel();
            for (int i = 1; i < dt.Rows.Count; i++)
            {
                switch (dt.Rows[i].ItemArray[0].ToString())
                {
                    case "Mandatory and Optional":
                        MainLogic(newdicValue, dicJson, dt, i, "MandatoryandOptional");
                        break;
                    case "Only Mandatory Fields":
                        MainLogic(newdicValue, dicJson, dt, i, "OnlyMandatoryFields");
                        break;
                    case "Only Optional Fields":
                        MainLogic(newdicValue, dicJson, dt, i, "OnlyOptionalFields");
                        break;
                    case "UpdateEachValue_Individually":
                        MainLogic(newdicValue, dicJson, dt, i, "UpdateEachValue_Individually");
                        break;
                }
            }
        }

        public static void MainLogic(Dictionary<string, string> newdicValue, Dictionary<string, string> dicJson, DataTable dt, int i, string casename)
        {
            newdicValue = new Dictionary<string, string>();
            foreach (var dval in dicJson)
            {
                int j = -1;
                foreach (var drow in dt.Rows[0].ItemArray)
                {
                    j++;
                    if (((KeyValuePair<string, string>)dval).Key == drow.ToString())
                    {
                        if (!string.IsNullOrEmpty(dt.Rows[i].ItemArray[j].ToString()))
                        {
                            newdicValue.Add(dval.Key.ToString(), dt.Rows[i].ItemArray[j].ToString());
                        }
                        else
                        {
                            newdicValue.Add(dval.Key.ToString(), "");
                        }
                    }
                }
            }
            ReturnJObject(newdicValue, casename);
        }

        static bool ParseJson(JToken token, Dictionary<string, string> nodes, string parentLocation = "")
        {
            if (token.HasValues)
            {
                foreach (JToken child in token.Children())
                {
                    if (token.Type == JTokenType.Property)
                    {
                        if (parentLocation == "")
                        {
                            parentLocation = ((JProperty)token).Name;
                        }
                        else
                        {
                            parentLocation += "." + ((JProperty)token).Name;
                        }
                    }
                    ParseJson(child, nodes, parentLocation);
                }
                return true;
            }
            else
            {
                if (nodes.ContainsKey(parentLocation))
                {
                    nodes[parentLocation] += "|" + token.ToString();
                }
                else
                {
                    nodes.Add(parentLocation, token.ToString());
                }
                return false;
            }
        }

        static void ReturnJObject(Dictionary<string, string> dickeyval, string casename)
        {
            StringBuilder sb = new StringBuilder();
            string filename = sb.AppendFormat("{0}{1}{2}{3}{4}", Directory.GetCurrentDirectory() + "\\Results", "\\", casename, DateTime.Now.ToString("yyyy-MM-dd-HH-mm"), ".json").ToString();
            JObject jsonObj = JsonConvert.DeserializeObject(File.ReadAllText(json), new JsonSerializerSettings() { NullValueHandling = NullValueHandling.Ignore }) as JObject;
            JToken jToken = null;
            foreach (var newvalue in dickeyval)
            {
                if (newvalue.Key.Contains("."))
                {
                    List<string> key = newvalue.Key.Split('.').ToList();
                    key.Insert(1, "[0]");
                    StringBuilder sbnew = new StringBuilder();
                    string newstring = string.Empty;
                    foreach (string str in key)
                    {
                        newstring = sbnew.AppendFormat("{0}{1}", str, ".").ToString();
                    }
                    newstring = newstring.TrimEnd('.').Replace(".[0]", "[0]");
                    jToken = jsonObj.SelectToken(newstring);
                    jToken.Replace(newvalue.Value);
                }
                else
                {
                    jToken = jsonObj.SelectToken(newvalue.Key);
                    jToken.Replace(newvalue.Value);
                }
            }
            foreach(var removechild in dickeyval)
            {
                if(removechild.Value == "NoField")
                {
                    jsonObj.Remove(removechild.Key);
                }
            }
            string output = JsonConvert.SerializeObject(jsonObj, Formatting.Indented);
            File.WriteAllText(filename, output);
        }
    }
}
